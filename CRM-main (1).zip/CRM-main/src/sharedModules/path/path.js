const REACT_BACKEND="http://localhost:8000"
export const LOGIN=REACT_BACKEND+"/api/auth/signin"
export const TABLE=REACT_BACKEND+"/api/customer"